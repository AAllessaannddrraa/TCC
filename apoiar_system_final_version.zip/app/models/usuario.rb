class Usuario < ApplicationRecord
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  validates :nome, presence: true, length: { minimum: 3 }
  validates :email, presence: true, format: { with: URI::MailTo::EMAIL_REGEXP }, uniqueness: true

  # Roles
  enum role: { cliente: 0, cuidador: 1, admin: 2 }

  # Associations
  has_many :servicos, foreign_key: :cliente_id, dependent: :destroy

  # Check if the user is an admin
  def admin?
    role == "admin"
  end

  # Check if the user is a caregiver
  def cuidador?
    role == "cuidador"
  end

  # Check if the user is a client
  def cliente?
    role == "cliente"
  end
end
