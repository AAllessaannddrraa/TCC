class UsersController < ApplicationController
  before_action :authenticate_usuario!
  before_action :authorize_admin

  def index
    @usuarios = Usuario.all
  end

  def show
    @usuario = Usuario.find(params[:id])
  end

  def edit
    @usuario = Usuario.find(params[:id])
  end

  def update
    @usuario = Usuario.find(params[:id])
    if @usuario.update(usuario_params)
      redirect_to users_path, notice: 'Usuário atualizado com sucesso.'
    else
      render :edit
    end
  end

  def destroy
    @usuario = Usuario.find(params[:id])
    @usuario.destroy
    redirect_to users_path, notice: 'Usuário excluído com sucesso.'
  end

  private

  def authorize_admin
    redirect_to root_path, alert: 'Acesso negado!' unless current_usuario.admin?
  end

  def usuario_params
    params.require(:usuario).permit(:nome, :email, :role)
  end
end
