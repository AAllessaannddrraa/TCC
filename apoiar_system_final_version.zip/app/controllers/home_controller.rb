# app/controllers/home_controller.rb
class HomeController < ApplicationController
  def index
    # Página inicial
  end
end
