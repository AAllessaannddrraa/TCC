class UsuariosController < ApplicationController
  before_action :authenticate_usuario!
  before_action :set_usuario, only: [:edit, :update, :destroy]

  def index
    @usuarios = Usuario.all
  end

  def new
    @usuario = Usuario.new
  end

  def create
    @usuario = Usuario.new(usuario_params)
    if @usuario.save
      redirect_to root_path, notice: 'Usuário cadastrado com sucesso.'
    else
      render :new
    end
  end

  def edit; end

  def update
    if @usuario.update(usuario_params)
      redirect_to root_path, notice: 'Perfil atualizado com sucesso.'
    else
      render :edit
    end
  end

  def destroy
    @usuario.destroy
    redirect_to root_path, notice: 'Conta excluída com sucesso.'
  end

  private

  def set_usuario
    @usuario = current_usuario
  end

  def usuario_params
    params.require(:usuario).permit(:nome, :email, :password, :password_confirmation)
  end
end
