Rails.application.routes.draw do
  root 'pages#home'

  # Devise routes para autenticação
  devise_for :usuarios

  # Rotas para administração (somente admin)
  resources :users, only: [:index, :show, :edit, :update, :destroy]

  # Rotas para gerenciamento de perfil
  resources :usuarios, only: [:edit, :update, :destroy]

  # Outras rotas existentes
  resources :solicitations
  resources :payments
  resources :notifications
end
