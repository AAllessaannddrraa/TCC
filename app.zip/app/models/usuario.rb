
class Usuario < ApplicationRecord
  # Devise modules for authentication
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  # Validations
  validates :nome, presence: true, length: { minimum: 3 }
  validates :email, presence: true, format: { with: URI::MailTo::EMAIL_REGEXP }, uniqueness: true
  validates :password, presence: true, length: { minimum: 6 }

  # Associations
  has_many :servicos, foreign_key: :cliente_id, dependent: :destroy

  # Role checkers
  def admin?
    role == "admin"
  end

  def cuidador?
    role == "cuidador"
  end

  def cliente?
    role == "cliente"
  end

  def supervisora?
    role == "supervisora"
  end

  def financeiro?
    role == "financeiro"
  end

  def rh?
    role == "rh"
  end
end
