class TipoServico < ApplicationRecord
end
