class CuidadorTreinamento < ApplicationRecord
  belongs_to :cuidador
  belongs_to :treinamento
end
