class Apoio < ApplicationRecord
  belongs_to :cliente
  belongs_to :supervisora
end
