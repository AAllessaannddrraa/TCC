# app/models/cuidador.rb
class Cuidador < ApplicationRecord
  has_many :turnos
  has_many :feedbacks
  has_many :servicos

  validates :nome, presence: true
  validates :nif, presence: true, uniqueness: true
  validates :email, presence: true, uniqueness: true, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :numero_contato, presence: true, uniqueness: true

  # Método para criar dados fictícios de cuidadores para testes
  def self.create_fake_cuidadores(count = 10)
    count.times do
      Cuidador.create!(
        nome: Faker::Name.name,
        data_nascimento: Faker::Date.birthday(min_age: 18, max_age: 65),
        nif: Faker::Number.unique.number(digits: 9),
        email: Faker::Internet.unique.email,
        numero_contato: Faker::PhoneNumber.unique.cell_phone
      )
    end
  end
end
