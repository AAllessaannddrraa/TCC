class Cliente < ApplicationRecord
end
