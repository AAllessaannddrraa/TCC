class Equipamento < ApplicationRecord
  belongs_to :apoio
end
