class Treinamento < ApplicationRecord
end
