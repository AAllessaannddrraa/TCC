class Relatorio < ApplicationRecord
  belongs_to :apoio
end
